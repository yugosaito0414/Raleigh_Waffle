<?php
$name = $post['name']
$visitor_email = $post['email']
$subject = $post['subject']
$message = $post['message']

$email_from = 'info@raleighwaffle.com';
$email_subject = 'new form submission';

$email_body =  'User Name': $name.\n”.
                'User email': $visitor_email.\n”.
                'subject': $subject.\n”.
                'message': $message.\n”;

$to = 'yugosaito0414@gmail.com';

$headers = "from: $email_form \r\n”;

$headers .="reply-To: $visitor_email \r\n”;

mail($to,$email_subject, $email_body, $headers);

header("Location: contact.html");

?>
